package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

type Command interface {
	Execute()
}

type LightReceiver struct{}

func (l *LightReceiver) TurnOn() {
	fmt.Println("Свет включен")
}

func (l *LightReceiver) TurnOff() {
	fmt.Println("Свет выключен")
}

type LightOnCommand struct {
	light *LightReceiver
}

func (c *LightOnCommand) Execute() {
	c.light.TurnOn()
}

type LightOffCommand struct {
	light *LightReceiver
}

func (c *LightOffCommand) Execute() {
	c.light.TurnOff()
}

type RemoteControl struct {
	command Command
}

func (r *RemoteControl) SetCommand(command Command) {
	r.command = command
}

func (r *RemoteControl) PressButton() {
	r.command.Execute()
}

func main() {
	light := &LightReceiver{}

	lightOn := &LightOnCommand{light: light}
	lightOff := &LightOffCommand{light: light}
	var lightswitch bool = false

	remote := &RemoteControl{}
	reader := bufio.NewReader(os.Stdin)
	switch lightswitch {
	case false:
		fmt.Println("Свет выключен. Включить?")
	case true:
		fmt.Println("Свет включен. Выключить?")
	}

	input, _ := reader.ReadString('\n')
	input = strings.TrimSpace(input)

	switch input {
	case "Включить":
		remote.SetCommand(lightOn)
		remote.PressButton()
		lightswitch = true

	case "Выключить":
		remote.SetCommand(lightOff)
		remote.PressButton()
		lightswitch = false
	}

}
